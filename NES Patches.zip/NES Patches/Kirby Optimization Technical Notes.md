# Kirby's Adventure (USA, Rev 1): Performance Engineering Handoff

**Document purpose:** Complete, reproducible technical specification of the performance-modified NES ROM, written for both human maintainers and AI coding agents. This document includes the complete source-code modification as an embedded unified diff. A matching **unmodified USA Rev 1 ROM**, the specified **disassembly/source repository**, this document, and a compatible **ca65/ld65 assembler** are sufficient to reconstruct the final ROM without any prior conversation or intermediate patch files.

**Target build:** Kirby's Adventure, USA Rev 1, performance-optimized ROM (canonical SHA-256 below).  
**Status:** Independently rebuilt byte-for-byte from the embedded source patch; isolated CPU execution and differential tests available. User testing impressions indicate substantially smoother gameplay under load. A separate public compatibility comment reports successful play using an EverDrive N8 on an AV Famicom, while also noting occasional frame drops during heavy scrolling. These are user observations, not independent hardware certification or controlled frame-rate measurements. Not verified across every level or gameplay edge case.  
**Scope:** Six source-level optimizations, original music/graphics data and full Spark particle script retained.

---

## 1. Canonical inputs and expected output

| Property | Required value |
|---|---|
| Game | `Kirby's Adventure (USA) (Rev 1).nes` |
| Unmodified ROM SHA-256 | `a7a742f5288cd4ab220f530ee7c8d0e3714b8bf107e89c9bf03039217fec5829` |
| Unmodified ROM MD5 | `a3dde61df4bc4ebce2a60c2cf869081e` |
| Source repository | Nathan-R-Og / `kirbyadventure`, source distribution `kirbyadventure-master.zip` |
| Known-good source ZIP SHA-256 | `5c389ba132f87377217b13a7a0f74bcfbc1a5b3f14a7235e7f99dabf5c998106` |
| Clean `src/prg/constant.asm` SHA-256 | `a82ced9e8c4a2137b98401353272b8d9bf04afe6b91eb8d9de98b602ce96a125` |
| Clean `src/prg/bank16.asm` SHA-256 | `c072b903c96ed7d3183480af773c0864d822d540a3dd00205120b09c2b7895bc` |
| Assembler/linker | ca65 and ld65, cc65 **V2.19**, from the tested `cc65-master.zip` archive or a compatible installation |
| Tested cc65 source ZIP SHA-256 | `8ec1f14c2d5ef98ab40a8aae08d94ade65de7241b4fa90a71c8198d4547f406d` |
| Final ROM filename | `kirby_rebuilt.nes` (the source project's normal output) |
| **Final ROM SHA-256** | **`e9265a2723ee4dc7a4c4ab97bb418aa89319419d9f540a1533287bf2fd7fc378`** |
| Final ROM length | 786,448 bytes (`0xC0010`) |
| Mapper / format | iNES, MMC3 mapper 4, 512 KiB PRG ROM, 256 KiB CHR ROM |
| Modification footprint | 237 byte values differ from the unmodified ROM, in 25 contiguous difference runs |
| Preservation | iNES header and entire CHR ROM are byte-identical to the retail ROM |

The final build was independently reconstructed from the named source archive, clean Rev 1 ROM, and the source modifications contained in this document, then compared **byte-for-byte** with the canonical output ROM. Both yielded the final SHA-256 above. These checks establish reproducibility of the build, not universal gameplay correctness.

### What is and is not modified

- Modifies **gameplay frame synchronization** without changing the original generic `WaitFrame` routine used elsewhere.
- Modifies **Spark terrain-collision calls**, but preserves its main damage hitbox, physics, two regular decorative particle creation attempts per scripted cycle, animation, and sound-effect script.
- Optimizes a **shared map-coordinate calculation**, sprite-buffer clearing, the object ActionScript interpreter, and the shared pseudorandom generator.
- **Does not** modify the music engine, remove particles, rewrite Beam, alter CHR graphics, modify the retail level maps, change NES hardware frame rate, or intentionally change controller semantics.
- Spark collision caching is **not behavior-preserving in all circumstances**; the precise limitation is documented below.

---

## 2. Rebuild instructions: exact, from a clean source tree

The upstream repository includes `configure.py`, which extracts approximately 938 binary source assets from a ROM matching the MD5 in `split.yaml`. The build uses `src/main.asm`, `linker.cfg`, Python 3, PyYAML, ca65, and ld65. The ROM must be present in the repository root when `configure.py` runs.

### 2.1 Prepare the toolchain and source

Use Linux/WSL, macOS with an equivalent assembler installation, or another environment supporting the scripts and tools. The tested environment built ca65/ld65 from the provided cc65 source using `make -j4 bin`. If no compatible tools are installed, acquire/build cc65 V2.19 first. Ensure `ca65` and `ld65` are on `PATH`.

```bash
# Directory names here assume the source ZIP and original ROM have been extracted.
# Install Python dependency if necessary:
python3 -m pip install PyYAML

# Example if building the cc65 source tree yourself:
cd /path/to/cc65-master
make -j4 bin
export PATH="$(pwd)/bin:$PATH"

# In a separate checkout/extraction of the specified game disassembly:
cd /path/to/kirbyadventure-master
cp '/path/to/Kirby'"'"'s Adventure (USA) (Rev 1).nes' .
sha256sum "Kirby's Adventure (USA) (Rev 1).nes"
# Must match a7a742f5...fec5829.
```

**Source matching is important.** Other disassemblies or different revisions may have the same named routines but different addresses, source formatting, asset splits, or linker structure. The embedded patch is intended for the exact source layout identified above. Do not blindly apply it to other revisions.

### 2.2 Extract the complete source patch embedded in this document

Save this Markdown file in a location accessible to the following command. The markers are fixed; the command extracts **only** the unified diff, not the Markdown explanation.

```bash
python3 - "Kirbys_Adventure_Rev1_Performance_Engineering_Handoff.md" <<'PY'
import pathlib, sys
text = pathlib.Path(sys.argv[1]).read_text(encoding='utf-8')
a = text.index('<!-- BEGIN_CANONICAL_SOURCE_PATCH -->')
a = text.index('```diff\n', a) + len('```diff\n')
b = text.index('\n```', a)
pathlib.Path('kirby-performance-final.patch').write_text(text[a:b] + '\n', encoding='utf-8')
print('Created kirby-performance-final.patch')
PY
```

If the document is outside the working directory, pass its absolute path instead.

### 2.3 Apply, extract assets, build, and verify

```bash
# Run in the *clean* kirbyadventure-master repository root.
patch -p1 --dry-run < kirby-performance-final.patch
patch -p1 < kirby-performance-final.patch

# This step needs the exact clean Rev 1 ROM in the repository root.
python3 configure.py

# Uses ca65 + ld65 via PATH.
python3 build.py

sha256sum kirby_rebuilt.nes
# Must be:
# e9265a2723ee4dc7a4c4ab97bb418aa89319419d9f540a1533287bf2fd7fc378
```

The normal `build.py` invokes ca65 on `src/main.asm` and ld65 with `linker.cfg`. It outputs `kirby_rebuilt.nes` and a `linked.txt` symbol list. Before distributing anything, verify the final ROM hash, ROM size, original header, and CHR identity. If the hash does not match, **do not assume the generated ROM is equivalent**: check source version, ROM revision, assembler version, application of the unified patch, and whether stale `split/` contents were generated from a different ROM.

### 2.4 Reference integrity check (Python)

```python
from pathlib import Path
from hashlib import sha256

vanilla = Path("Kirby's Adventure (USA) (Rev 1).nes").read_bytes()
final = Path('kirby_rebuilt.nes').read_bytes()
assert len(vanilla) == len(final) == 786448
assert sha256(vanilla).hexdigest() == 'a7a742f5288cd4ab220f530ee7c8d0e3714b8bf107e89c9bf03039217fec5829'
assert sha256(final).hexdigest() == 'e9265a2723ee4dc7a4c4ab97bb418aa89319419d9f540a1533287bf2fd7fc378'
assert final[:16] == vanilla[:16], 'iNES header changed'
assert final[0x80010:] == vanilla[0x80010:], 'CHR data changed'
assert sum(a != b for a, b in zip(vanilla, final)) == 237
print('PASS: canonical performance build reproduced')
```

---

## 3. Engine layout and address conventions

The game uses MMC3's 8 KiB PRG banks. `src/prg/constant.asm` contains the fixed high-PRG routines and the primary game loop. `src/prg/bank16.asm` contains the Spark attack callback. `src/prg/bank21.asm` contains the original collision scanner.

**Important address convention:** Mesen identifies `PRG: $7ECF1` as a *PRG ROM offset excluding the 16-byte iNES header*, not as a CPU address. In the final fixed bank, this maps to CPU `$ECF1` and full `.nes` file offset `$7ED01`. Generally, `ROM file offset = Mesen PRG offset + $10` for an iNES ROM without a trainer. Do not write raw CPU hooks using a PRG offset.

| Component | CPU address | Mesen PRG offset | Source / notes |
|---|---:|---:|---|
| `B3E_c067`, generic `WaitFrame` | `$C067` | `$7C067` | `constant.asm`, unchanged |
| `B3E_c8dd`, RNG entry | `$C8DD` | `$7C8DD` | `constant.asm` |
| ActionScript interpreter entry | `$CDAD` | `$7CDAD` | `constant.asm` |
| OAM clear | `$DE03` | `$7DE03` | `constant.asm` |
| Main gameplay loop `B3F_e48c` | `$E48C` | `$7E48C` | `constant.asm` |
| Map coordinate divider `B3F_ecf1` | `$ECF1` | `$7ECF1` | `constant.asm` |
| Spark collision-cache helper | `$F8E9` | `$7F8E9` | `constant.asm`, added code |
| Gameplay wait helper | `$F930` | `$7F930` | `constant.asm`, added code |
| Scanline IRQ entry | `$F940` | `$7F940` | **Must preserve** IRQ prologue |
| Spark attack callback `B16_a17e` | `$A17E` | `$2C17E` | `bank16.asm`, bank `$16` |
| Spark original collision scanner | `$9420` | `$43420` | `bank21.asm`, bank `$21` |
| Full collision entry used by cache | `$9426` | `$43426` | `bank21.asm`, bank `$21` |

The original source contains hard-coded absolute CPU addresses and script pointers. The final patch uses fixed-size replacements or reclaimed space so **all original named symbols keep their addresses** (the original build had 16,776 symbols; the final build adds a handful of labels). This is a hard compatibility constraint, not merely a source formatting preference.

---

## 4. Final modification specifications

These six changes are organized by expected practical impact, not by implementation chronology. The complete, directly applicable **actual assembly changes** are in §8; the sections here describe their contracts, invariants, and measured effects.

### 4.1 Gameplay-only NMI frame-latch scheduling

**Implementation:** `src/prg/constant.asm`, `B3F_e48c` at CPU `$E48C`, helper `WaitGameplay` at `$F930`.

The retail gameplay loop calls `B3E_c067` to wait for a new PPU VBlank NMI. That function resets `nmi_done_flag` before its polling loop. If an NMI has already occurred while the preceding gameplay update was running, the reset discards evidence of that interrupt and the loop may wait an additional display frame.

The modified gameplay call goes through the following helper, reproduced here for quick reference. Its full patch context is in §8:

```asm
WaitGameplay:
    lda nmi_done_flag
    bne @already_elapsed
    jsr B3E_c067
@already_elapsed:
    lda #$00
    sta nmi_done_flag
    rts
```

**Semantics:** If an NMI notification is already pending, consume it and continue; otherwise use the unchanged retail wait. Clear the notification exactly once before continuing with the next gameplay update. Only the **normal gameplay loop** uses this helper. Other waits, menus, transitions, and related synchronization paths continue calling `B3E_c067` directly.

**Space/IRQ requirement:** The 12-byte helper occupies `$F930–$F93B`. Bytes `$F93C–$F93F` are preserved as `$EA,$E6,$AA,$AE`. The live scanline IRQ handler begins **at `$F940`**, and its entry instructions (`NOP; TYA; PHA; LDY #$09`) plus all subsequent IRQ bytes must be preserved. The patch asserts these addresses at assembly time.

**Why this matters:** The original Boolean-like frame acknowledgment can discard an NMI that arrived during a long gameplay update. The helper recognizes an already-pending notification, avoiding a redundant wait in that case. An **isolated CPU test of 10,000 flag/wait scenarios** verified the intended path selection and flag consumption (17 cycles when the NMI is already pending; 22 helper cycles plus the original wait path otherwise). These are helper-path costs, not whole-game frame-rate measurements. User testing impressions describe much smoother performance in busy scenes; no controlled per-frame gameplay rate is claimed.

**Remaining risks:** Two gameplay updates can occur unusually close together after an overrun. NMI timing and PPU update-buffer expectations still need full instrumentation. An NMI occurring between the helper's initial check and `B3E_c067` clearing the flag can still be lost. The change cannot make execution faster than the NES CPU's actual capacity.

### 4.2 Spark no-hit collision memoization

**Implementation:** `src/prg/bank16.asm` Spark `B16_a17e` changes one `JSR` from `$9420` to `SparkCollisionCache` (`$F8E9`) in `src/prg/constant.asm`. Collision algorithm in `bank21.asm` remains original.

The new helper computes an 8-bit XOR/shift signature of Spark's hitbox coordinates, dimensions, flags, current room, and `$051E` map mode. It compares that signature with `$79B0` and consults a small expiration counter at `$79B1`.

- On a changed signature or expiration, call the original collision scanner's full entry **at `$9426`**, with accumulator `A=0` to match the original `$9420` setup.
- After a carry-clear scan (no reported hit), allow **up to three** subsequent same-signature cached carry-clear returns.
- After a carry-set scan (hit), clear the expiry counter; do not reuse a no-hit result.
- Keep Spark physics, hitbox formation, and the rest of the attack callback in their original order.
- Keep all original Spark particle-spawn operations, visual effects, and sounds. The cache applies only to Spark's specific call site.

**Cache layout:** `$79B0` = 8-bit signature, `$79B1` = remaining reuse count (0–3). These were not found in explicit source references, but are **not formally proven unused by all possible cartridge-RAM accesses**. Do not treat them as reserved by a public RAM map.

**Independently tested behavior and cost:** A 6502 instruction harness executed the built helper with the original collision scanner replaced by a controlled carry-result stub. In an unchanged, no-hit sequence, the helper performs **one complete scan followed by three cached no-hit returns**. The isolated cached return costs approximately **70 CPU cycles**, excluding the caller `JSR`, versus approximately **79 wrapper cycles plus the entire original collision scan** on a compulsory-scan path. In this favorable four-call pattern, exactly **three of four original scan invocations are avoided** by design; real-game cache hit rates and frame-rate impact were **not measured independently**. Tests included **2,048 randomized compulsory-scan initializations**, expiration, coordinate/room/hitbox changes, and carry-set invalidation.

**Important correctness limitation:** This is a deliberate approximation, **not** an equivalent collision algorithm. A no-hit collision call may still have terrain/interaction side effects, and the cache ignores terrain edits until its next compulsory scan. Its 8-bit signature can also collide. Destructible blocks, switches, moving terrain, and other interactive map elements may respond late or incorrectly. The full collision handler normally runs at least once every four same-signature calls, but this does not guarantee every interaction is detected. Future work should prioritize a side-effect-preserving terrain-data cache rather than propagating this shortcut globally.

### 4.3 Fast common-case map-coordinate division

**Implementation:** `src/prg/constant.asm`, `B3F_ecf1` CPU `$ECF1`.

The game frequently converts the `(X,Y)` coordinate pair into a map-data index by dividing the combined coordinate by 192. Original code performs several threshold/subtract/rotate steps even if the high component `X` is 0, 1, or 2. The modified routine skips those steps for `X < 3`, uses `LSR A` in the last remainder stage, and removes one provably unnecessary `CLC` in the supported input domain. Remaining input ranges take the more general path; invalid `X >= $60` still returns the original sentinel behavior.

**Isolated cycle counts:**

| Coordinate example | Retail-like divider | Optimized divider | Savings |
|---|---:|---:|---:|
| `X=0, Y=0` | 112 | 61 | 51 cycles |
| `X=1, Y=0` | 117 | 71 | 46 cycles |
| `X=2, Y=0` | 122 | 75 | 47 cycles |
| Selected `X>=3` | Input-dependent | Input-dependent | May be approximately 2–3 cycles slower |

The small-input specialization is shared by every caller of this coordinate routine, not exclusively Spark. For a sequence of `N` independent calls whose `X` coordinate is between 0 and 2, the isolated tests support savings of roughly `46N–51N` cycles for the shown low-page examples. Frequency under real gameplay and whole-frame gains are intentionally **not** inferred from outside profiler recordings.

**Validation:** 100,544 isolated instruction-level CPU comparisons matched the old routine's relevant outputs, scratch byte, registers, stack, and flags over tested inputs, including all valid `X=0..95`, all 256 low-coordinate values, and four accumulator seeds; additional out-of-range inputs were checked. The implementation is constrained to the original `$ECF1–$ED54` space and padded to keep subsequent entry points fixed.

### 4.4 Less redundant sprite-buffer clearing

**Implementation:** `src/prg/constant.asm`, `ClearOamBuffer1`, `ClearOamBuffer2`, and `ClearBothOamBuffers` near CPU `$DE11–$DE4A`.

The engine maintains two CPU-side OAM staging buffers at `$0200` and `$0300`. Hidden sprites need their Y positions set to `$F0`; clearing the immediately adjacent tile-number byte for every invisible sprite is unnecessary so long as the rendering paths initialize tile/attributes before revealing a sprite. Each clear routine therefore writes only the Y byte at 4-byte intervals. The double-buffer function also removes duplicate initialization of `$69` and `oam_index` between the two clears.

**Measured isolated savings:** A regular buffer clear: **1,351 → 1,031 cycles**, saving **320 cycles**, or ~1.1% of an NTSC video frame's ~29,780-cycle CPU budget. The double-buffer clear: **2,731 → 2,081 cycles**, saving 650 cycles. The changed sprite-buffer clearing is shared across the whole game.

**Invariant:** Neither buffer's inactive tile data is cleared anymore; no displayed sprite may rely on those stale tile bytes before explicitly writing them. Randomized isolated differential testing covered 1,536 setups and checked hidden-Y values, unrelated bytes, CPU registers, flags, and stack. Fixed-size NOP padding preserves subsequent source addresses.

### 4.5 Faster object ActionScript interpreter setup

**Implementation:** `src/prg/constant.asm`, ActionScript interpreter entry near CPU `$CDAD` and awake-script initialization/dispatch.

The engine has **32 script contexts**, each with a **16-byte stack** at `$6400–$65FF`. The specialized pointer calculation computes `16 * script_slot` with four accumulator shifts and sets the high byte to `$64 + carry`, rather than using repeated 16-bit generic shifts and memory rotates. The interpreter also skips a redundant upper-MMC3 bank write *only if* both the requested bank equals `upper_prg` and the live `ram_BANKSELECT` shadow equals `$87`. Waited-opcode decoding uses `TAY`/`TYA` instead of `PHA`/`PLA`. An always-taken `BNE` replaces filler NOPs without moving downstream labels.

**Isolated results:** Interpreter setup to first opcode fetch:

| Mapper condition | Original | Modified | Savings |
|---|---:|---:|---:|
| Required upper bank already mapped; select shadow `$87` | 105 cycles | 63 cycles | 42 |
| Same upper bank; select shadow not `$87` | 105 | 97 | 8 |
| Different upper bank | 105 | 91 | 14 |

Waited-opcode handling additionally saves approximately **3 cycles per opcode**. Tests included 512 interpreter setup conditions, 26,496 opcode-dispatch comparisons, and 576 complete waited-pose/timer ticks. The interpreter runs for object scripts in general; it is **not a Spark-only modification**.

**Invariant:** Do not generalize the mapper optimization without tracking active MMC3 register selection and the NMI/IRQ restoration scheme. Matching the target bank value alone is insufficient.

### 4.6 Equivalent RNG state update with fewer rotations

**Implementation:** `src/prg/constant.asm`, shared random-number generator `B3E_c8dd` and its 11-round feedback loop at `$C8E8`.

Each LFSR-like state update produces the same feedback bit as the original code using a simpler expression:

```text
feedback = 1 XOR previous_low.bit0 XOR previous_low.bit1 XOR previous_high.bit7
```

The implementation replaces several accumulator rotates and repeated XOR operations with `LSR`, `EOR`, `AND`, `ASL`, `ROL`, and an `ADC #$00` that exploits the 2A03's binary-only arithmetic. It leaves the bounded random-number scaling algorithm unchanged.

**Measured isolated savings:** **506 → 423 cycles** for an RNG invocation: 83 fewer cycles (~16.4%). Spark's particle initialization can request two random values per particle; when that exact path runs, savings are ~166 cycles per particle initialization before considering other overhead.

**Validation:** A state-update model matched **all 65,536 possible 16-bit states**. Another 4,096 isolated instruction comparisons checked raw and bounded-call behavior. **Caveat:** raw/unbounded RNG calls can leave carry/overflow flags different from retail even though returned random values, state, and other checked outputs match. Bounded Spark-range calls passed the reported final flag checks. Future callers must not make undocumented assumptions about post-RNG carry or overflow.

---

## 5. Independent validation and performance evidence

### 5.1 Evidence levels and measurement methodology

Performance results here come **only from locally executed instruction-level tests and deterministic mathematical checks** associated with this source patch. Cycle counts describe individual routines or controlled helper paths, **not a benchmark of real gameplay FPS**. The CPU harness executes the relevant assembled 6502 machine code or an explicitly identified subroutine stub. As appropriate, it checks registers, flags, scratch RAM, the stack, random-state evolution, and control flow against the retail implementation.

**Important distinctions:** Inclusive cycle costs within nested routines must not be added to each other. Expected savings from avoiding a large real collision scan cannot be equated with measured in-game CPU savings unless the full scan is actually profiled under equivalent inputs. Video refresh rate (~60.1 Hz on NTSC) is not the same as completed gameplay updates per second. Reports of smooth gameplay are labeled as user testing impressions, not benchmark data.

### 5.2 Isolated CPU-cycle improvements

| Code path | Original | Optimized | Independently established result |
|---|---:|---:|---|
| Map-coordinate division, `X=0,Y=0` | 112 cycles | 61 cycles | Saves **51** cycles |
| Map-coordinate division, `X=1,Y=0` | 117 | 71 | Saves **46** cycles |
| Map-coordinate division, `X=2,Y=0` | 122 | 75 | Saves **47** cycles |
| Map-coordinate division, `X=10,Y=0` | 119 | 122 | **3-cycle regression** outside the common low-page fast path |
| One OAM staging-buffer clear | 1,351 | 1,031 | Saves **320** cycles |
| Both OAM staging buffers | 2,731 | 2,081 | Saves **650** cycles |
| ActionScript setup, upper bank already mapped and select shadow `$87` | 105 | 63 | Saves **42** cycles |
| ActionScript setup, matching bank but select shadow not `$87` | 105 | 97 | Saves **8** cycles |
| ActionScript setup, different upper bank | 105 | 91 | Saves **14** cycles |
| Shared RNG invocation in the isolated benchmark | 506 | 423 | Saves **83** cycles (~16.4%) |

The row values reflect particular test setups; not every caller or coordinate gives the same saving. The game may have additional timing constraints unrelated to these function costs.

### 5.3 Isolated Spark collision-helper behavior

| Test condition | Observed helper behavior |
|---|---|
| No-hit, unchanged hitbox over four consecutive calls | First call invokes original scanner; next three return cached carry-clear |
| Unchanged no-hit cached return | Approximately **70 cycles** in the isolated harness, excluding caller `JSR` |
| Compulsory scan path | Approximately **79 helper cycles**, **plus** the actual collision scanner (stubbed for the isolated test) |
| Previous collision scanner reported carry set | Cache is not reused |
| Modified sampled position, room, or hitbox size | Cache invalidates in the tested cases |
| Randomized compulsory-scan initializations | **2,048** successful cases |

The helper has a best-case **75% scan-elision rate by construction** when a hitbox and its compact signature remain unchanged and every compulsory scan reports no hit. This is **not** a measured real-world hit rate, total CPU saving, or FPS improvement. Because it skips effectful scanner calls, the optimization is approximate and may affect terrain interactions.

### 5.4 Other independently performed checks

- **100,544** map-divider CPU comparisons across the documented valid and invalid test inputs.
- **65,536** two-byte RNG state transitions checked against a mathematical reference model, plus **4,096** isolated instruction comparisons of RNG behavior.
- **512** script-interpreter setup conditions, **26,496** opcode dispatch comparisons, and **576** waited-script ticks.
- **1,536** randomized OAM clearing setups, checking memory state and CPU preservation invariants.
- **10,000** isolated gameplay NMI latch scenarios, confirming both the already-pending and wait-needed branches, and consumption of the flag.
- Clean-source application and byte-for-byte ROM rebuild verified against the SHA-256 in §1.

**Unmeasured by these tests:** whole-game FPS, worst-case scrolling-frame latency, actual audio-engine cost, full sprite workload during crowded scenes, hardware electrical compatibility, and compatibility with other ROM hacks. Use deterministic emulator instrumentation before claiming improvements in any of those areas.

## 6. Validation checklist and operational invariants

**Build-time validation already performed:**

- A clean source rebuild matches the retail Rev 1 ROM exactly before patching.
- The complete final source patch in this document applies cleanly to the identified source archive.
- The modified source compiles and links using the pinned cc65 assembler version.
- The rebuilt file SHA-256 equals the canonical final value exactly.
- All original named source entry points retain their addresses; additional helper labels occupy known fixed-bank space.
- Header, mapper, PRG/CHR sizes, and all CHR bytes are unchanged.
- Source-level assertions protect the `$F930–$F93B` wait-helper size, `$F940` IRQ prologue, and map-divider/code-cave capacity.
- Isolated CPU tests exercised interpreter setup and opcode decoding, RNG sequences, OAM buffers, map division, Spark collision-helper branches, and gameplay latch states. These tests are *not* a substitute for running full game situations.

**Runtime acceptance tests for a maintainer:**

1. Boot, intro, title, file select, world hub, doors, map and room transitions. Ensure **no half-screen, split-scroll, status-bar, or IRQ glitches**. Inspect camera movement across sustained scrolling in both sparse and enemy/projectile-heavy scenes.
2. Sustained Spark: stationary in an empty room, next to destructible blocks, near water, with multiple enemies, and across camera/room boundaries. Check both speed and collision/interaction behavior.
3. Beam, Needle, Freeze, Fire, Ice, Sword, Hammer, Cutter, Stone, Light, and other abilities. Confirm animations, collision hits, and any ability-specific state changes remain consistent.
4. Sprite rendering: crowded enemies and projectiles, enemy spawning/despawning, full OAM conditions, pause/unpause, and scene transitions.
5. Audio: music changes, sustained Spark sound, SFX priority, and long-note transitions. Confirm the sound output stays correct while gameplay overruns frame boundaries.
6. Save/load and power/reset handling, including SRAM persistence and any overlap with `$79B0–$79B1`.
7. Run identical recorded inputs on unmodified and optimized ROMs; compare per-frame NMI count, `OBJ_Main` calls, CPU cycles, missed game updates, and visual correctness. Repeat with **moving camera vs stationary camera** to identify scrolling-specific stalls.
8. On compatible real hardware, check an EverDrive N8 with an AV Famicom as one reported functioning configuration; test boot, scrolling, audio, SRAM, and long sessions. Treat all hardware results as configuration-specific, not universal guarantees.
9. For potential ROM-hack compatibility, compare modifications and mapper/IRQ usage on each candidate hack. Build and test a combined patch separately; do not assume IPS patches commute or preserve source/PRG addresses.

**Stop conditions:** incorrect IRQ scrolling, crash, unexpected sprite corruption, lost ability functionality, failure to update destructible terrain, sound desynchronization, save-state corruption, or hash mismatch during reconstruction.

### 6.1 User-testing and hardware compatibility observations (not benchmark data)

- User testing impressions describe substantially smoother gameplay, particularly under Spark and with multiple enemies onscreen. These observations are **not** frame-by-frame emulator instrumentation or a quantitative hardware benchmark.
- A separate public user comment reports that the patch ran as expected using an **EverDrive N8 on an AV Famicom**. This is a **single reported hardware configuration**, not independently reproduced by the maintainers of this document.
- The same comment notes that **scrolling can still drop a few frames when many things are happening**. The commenter also recalls observable scrolling slowdown in the unmodified game. These are reported observations, not independently measured comparative results. Treat **scrolling under heavy object/projectile load** as a specific remaining performance target.
- Compatibility with additional ROM hacks was **proposed for investigation**, not reported as tested. There is no established compatibility matrix for merging this performance patch with other modifications.

---

## 7. High-value, technically justified future work

The following are **not implemented in the canonical ROM**. They are forward-looking tasks and must preserve the existing ROM as a reproducible baseline.

### 7.1 Replace approximate Spark cache with a side-effect-preserving terrain-data cache

Instead of caching the entire collision result, cache **read-only tile classification and address calculations** within a small world-coordinate window. Every collision-handler invocation must still perform required side effects and dynamic hit tests. Invalidate cache entries on tile edits, room changes, scrolling into new map data, level reinitialization, or relevant bank/tileset mode changes. This could recover many of the collision-cache savings while removing the current risk of delayed interactions. Test every destructible or interactive tile type and every object/ability that uses the shared scanner.

### 7.2 Generalize safe terrain reuse to stationary area abilities

Spark is a strong case because repeated hitboxes often query the same tiles. Freeze and Needle may also benefit, but only after tracing actual call patterns and confirming the source's real collision entry points. Do **not** call the existing `$F8E9` helper from arbitrary objects: its two-byte cache is global and does not include object identity, and its carry-clear shortcut can suppress side effects. A reusable architecture needs per-object or per-context state, full-position verification (not only an 8-bit XOR signature), explicit cache invalidation, and an ability-aware interaction policy. Fast-moving projectiles generally benefit more from reusable **terrain read data** than from memoizing the collision result.

### 7.3 Profile object sprite assembly under maximum load

Hardware OAM DMA itself has a mostly fixed cost (~513/514 CPU cycles for 256 bytes) and is not the main variable with sprite count. Investigate the CPU routines that build sprites, transform coordinates, choose pattern tiles, handle clipping, and manage sprite buffers in `OBJ_Main`. Capture actual function-exclusive costs in scenes with many simultaneously active objects; optimize per-object dispatch and common cases before changing draw order, sprite limits, or object pools.

### 7.4 Reduce NMI audio spikes without corrupting shared RAM

The actual NMI sound update at fixed-bank CPU `$F8A0` (Mesen PRG offset `$7F8A0`) invokes the music engine. Its complete runtime cost and frame-to-frame variability **have not been measured independently for this handoff**. The music source contains a repeated-add loop at `B1D_82ce` used in note-duration arithmetic. A fixed-step shift/add or table lookup may help expensive note-event paths, but a substitute must match all input ranges, including loop-zero behavior, and preserve 6502 A/X/Y/flags and NMI-live scratch RAM. The existing game's fast multiply routine reuses scratch RAM also used by gameplay and is **not** safe to call from NMI without an explicit preservation contract. Compare actual audio samples and VBlank timing after any rewrite. No sound timing or waveform change is acceptable without a documented reason.

### 7.5 Instrument frame scheduling and eliminate ambiguous FPS metrics

Add emulator-side instrumentation (preferably Mesen breakpoints/trace hooks rather than extra ROM code) to record monotonically increasing NMI sequence number, each entry/exit to `OBJ_Main`, duration of gameplay work, OAM buffer index, and instances where a logical update was scheduled between two NMIs. Use deterministic input recordings. Distinguish video-refresh FPS, actual game-state updates/s, and apparent animation smoothness. Watch for latent races in the `nmi_done_flag` protocol. A more robust future scheduler could use separate produced/consumed NMI counters instead of a Boolean-like byte, but only after analyzing every call path that reads or writes the existing flag and preserving pause/menu behavior.

### 7.6 Extend map lookup optimization based on actual X-value distributions

The `$ECF1` fast lane helps X values 0–2 and can be slightly slower outside that range. Instrument X/Y distributions across later worlds, bosses, and moving-camera scenes. If measurements justify it, replace the general arithmetic with a proven faster equivalent or a compact high-byte table, including exact quotient/remainder/flags and no hidden mapper-side effects. Ensure the binary keeps subsequent entry points fixed or update all hard-coded pointers correctly. Avoid shipping a fast lane just because its isolated benchmark looks attractive.

### 7.7 Target the scrolling engine when many objects are active

User testing feedback identifies **occasional dropped frames during heavy camera scrolling**, including on actual EverDrive N8 / AV Famicom hardware. A commenter reports that the original retail game could also slow down while scrolling. Neither the exact cause nor a quantitative before/after comparison has been independently established.

**Recommended investigation:** Identify camera-update entry points and the routines that prepare new offscreen nametable columns/rows, attribute-table updates, metatile decoding, PPU update lists, and any CHR-related transfers. Compare stationary and scrolling frames under **identical object/projectile and input conditions**, collecting per-NMI CPU cost, queued VRAM-write volume, scroll/IRQ state, and missed logical updates. Determine whether the limiting factor is CPU-side data preparation, VBlank transfer capacity, PRG bank switching, or synchronization to the raster split.

**Potential changes (not implemented):** Incrementally reuse map/metatile addresses across adjacent rows or columns; avoid redundant nametable/attribute writes; precompute immutable metatile decoding results; spread safe, noncritical VRAM preparation across frames; reduce duplicated camera-boundary/object-culling work. Do not skip essential tiles, alter collision geometry, exceed VBlank's limited VRAM-write window, or disturb the `$F940` scanline IRQ handler and its precise scroll split. A faster camera pipeline must preserve **visual scrolling continuity and correct world coordinates**.

### 7.8 Explore real-hardware and other-ROM-hack compatibility

The reported **EverDrive N8 on AV Famicom** success is encouraging but does not prove identical operation on other flash cartridges, hardware revisions, FPGA systems, or emulators. Perform sustained scrolling, Spark, audio, scene-transition, and reset/save tests across representative hardware. Record precise firmware and emulator versions with each result.

Other ROM hacks are **not automatically compatible**. Check for overlap in PRG offsets, fixed-bank code caves, IRQ/NMI vectors, `nmi_done_flag` semantics, tile collision hooks, mapper shadow variables, and cartridge RAM `$79B0–$79B1`. Modifications that relocate routines or alter the mapper/CHR layout need source-level merging and a fresh build, not naïve application of two IPS patches. Maintain a per-hack test matrix of actual observed behavior before claiming compatibility.

### 7.9 Ability-specific performance opportunities beyond Spark

**Stationary or continuous attacks:** Investigate Freeze and Needle for repeated terrain-region scans similar to Spark. First record exact native call paths and attack-specific side effects. Reuse immutable tile **data**, not a global carry-bit collision result, unless a complete safety proof exists.

**Moving or projectile-heavy attacks:** Beam and other projectile generators may be dominated by repeated per-object creation, physics, collision lookup, sprite assembly, and despawn work. Prefer bounded pool fast paths, efficient per-object iteration, and incremental coordinate conversion; preserve spawn counts, damage cadence, sprite behavior, and interactions. No ability-specific code beyond Spark's one collision call is modified by this handoff.

**General rule:** Profile abilities separately with zero enemies, many enemies, a static camera, and a moving camera. A scene that scrolls heavily may have a different limiting subsystem than stationary Spark. Mark each proposal as unimplemented until verified and merged into the canonical source patch.

### 7.10 Release discipline

For every extension: rebuild from the pinned clean source, commit a **separate source diff**, verify both original and modified SHA-256, preserve the known-good ROM, run isolated differential CPU tests, then run deterministic whole-game scenarios. Do not conflate a pass in a miniature CPU test with complete gameplay equivalence. Prefer trace-driven changes over blanket effect removal or unconditional skipping of collision handlers.

---

## 8. Complete canonical source patch (clean disassembly → final ROM)

This unified diff is the **actual complete assembly change** needed to reconstruct the final optimized ROM. It modifies only `src/prg/constant.asm` and `src/prg/bank16.asm`. Apply it **once** to the pristine matching disassembly using `patch -p1`, not to a source tree that already includes some of these optimizations. Its source comments document important invariants. All introduced helper labels are descriptive and independent of the development chronology.

<!-- BEGIN_CANONICAL_SOURCE_PATCH -->
```diff
--- a/src/prg/constant.asm
+++ b/src/prg/constant.asm
@@ -1073,21 +1073,25 @@
 	lda random_number
 	ldx #$0b
 	@B3E_c8e8:
-	asl random_number
-	rol random_number+1
-	rol a
-	rol a
-	eor random_number
-	rol a
-	eor random_number
-	lsr a
-	lsr a
-	eor #$ff
-	and #$01
-	ora random_number
-	sta random_number
-	dex
-	bne @B3E_c8e8
+    ; Equivalent feedback bit: 1 XOR old_low.bit0 XOR old_low.bit1
+    ; XOR old_high.bit7.  Avoid six unnecessary accumulator rotates.
+    ; The accumulator already contains the previous low state byte,
+    ; including after the last STA random_number.
+    ; NES 2A03 always performs binary ADC.
+    lsr a
+    eor random_number
+    and #$01
+    asl random_number
+    rol random_number+1
+    adc #$00
+    and #$01
+    eor #$01
+    ora random_number
+    sta random_number
+    dex
+    bne @B3E_c8e8
+    nop
+    nop                       ; preserve original entry points
 	tax
 	pla
 	beq @B3E_c907
@@ -1704,34 +1708,45 @@
     sta script_ptr
     lda SCR_pc_hi,x
     sta script_ptr+1
+    ; Kirby-specific bank reuse: skip register writes ONLY when the live
+    ; selection is already PRG bank register 7 AND the PRG bank matches.
+    ; This preserves the shadow mapper-select byte and the NMI restore path.
     lda SCR_bank,x
+    cmp upper_prg
+    bne @switch_upper
+    ldy ram_BANKSELECT
+    cpy #$87
+    beq @upper_ready
+@switch_upper:
     jsr UpperBankswitch
+@upper_ready:
 
-    lda #$00
-    sta script_stack+1
+    ; Kirby hardcodes 32 script contexts, with exactly 16 bytes of stack
+    ; storage each, anchored at $6400. For X=0..31, 16*X needs just a low-byte shift and carry into $64/$65.
+    ; The generic multi-byte shift/rotate sequence is unnecessary.
     txa
     asl a
     asl a
-    rol script_stack+1
     asl a
-    rol script_stack+1
     asl a
-    rol script_stack+1
-    adc #<$6400
     sta script_stack
-    lda script_stack+1
-    adc #>$6400
+    lda #$64
+    adc #$00                ; add bit 4 of script index from final ASL
     sta script_stack+1
+    ; Preserve every original address downstream, including all scripts'
+    ; absolute CALL targets and the dispatch table.
+    bne SRC_loop            ; ADC high-byte is $64/$65: always nonzero,
+                            ; 3 cycles versus 4 for two NOPs
 
     SRC_loop:
     ldy #$00
     lda (script_ptr),y
     cmp #$50
     bcc @notwaited
-    pha
+    tay                     ; cheaper than stacking opcode just to mask it
     and #$0F
     sta SCR_sleep_timer,x
-    pla
+    tya
     sec
     sbc #$50
     lsr a
@@ -4318,41 +4333,57 @@
 	lsr a
 	bcs ClearOamBuffer2
 
+; Only the Y bytes of inactive NES OAM entries must be hidden.
+; Every path that *shows* a sprite writes its tile and attributes explicitly.
+; Preserve all original CPU registers/flags and the original ROM addresses.
 ClearOamBuffer1:
-	lda #$f0
+    lda #$f0
 B3E_de13:
-	sta $0200,y
-	sta $0201,y
-	iny
-	iny
-	iny
-	iny
-	bne B3E_de13
-	rts
+    sta $0200,y
+    iny
+    iny
+    iny
+    iny
+    bne B3E_de13
+    rts
+    ; Original STA $0201,Y consumed three bytes.
+    nop
+    nop
+    nop
 
 ClearOamBuffer2:
-	lda #$f0
+    lda #$f0
 B3E_de22:
-	sta $0300,y
-	sta $0301,y
-	iny
-	iny
-	iny
-	iny
-	bne B3E_de22
-	rts
+    sta $0300,y
+    iny
+    iny
+    iny
+    iny
+    bne B3E_de22
+    rts
+    nop
+    nop
+    nop
 
 ClearBothOamBuffers:
-	lda #$fc
-	sta $69
-	ldy #$00
-	sty oam_index
-	jsr ClearOamBuffer1
-	lda #$fc
-	sta $69
-	ldy #$00
-	sty oam_index
-	jmp ClearOamBuffer2
+    lda #$fc
+    sta $69
+    ldy #$00
+    sty oam_index
+    jsr ClearOamBuffer1
+    ; The first clear leaves $69, oam_index, and Y as they were (Y=0).
+    ; Reinitializing all three before the second buffer is redundant.
+    jmp ClearOamBuffer2
+    ; Occupy the former eight bytes after an unconditional JMP so the
+    ; subsequent ROM layout is absolutely unchanged.
+    nop
+    nop
+    nop
+    nop
+    nop
+    nop
+    nop
+    nop
 
 PlayMusic:
 	jsr Script_ReadByte
@@ -5174,7 +5205,7 @@
     lda #$00
     sta $0516
 B3F_e48c:
-    jsr B3E_c067
+    jsr WaitGameplay ; reuse an NMI that arrived during the preceding update
     jsr B3E_c32c
     lda pad_hold
     sta temp_pad1_hold
@@ -6219,75 +6250,79 @@
 .byte $CF,$CF,$CF,$CF,$3F,$3F,$3F,$3F
 .byte $00,$01,$02,$03,$00,$04,$08,$0C
 .byte $00,$10,$20,$30,$00,$40,$80,$C0
+; Frequent low-world-page fast lane. Divides (X:Y) by 192 with
+; exactly the same quotient, remainder and side effects as retail.
 B3F_ecf1:
     cpx #$60
-    bcc B3F_ecfa
+    bcc @valid
     ldy #$00
     lda #$ff
     rts
-B3F_ecfa:
+@valid:
     pha
     lda #$00
     sta UNK_0
     txa
+    cmp #$03
+    bcc @last_digit
     cmp #$30
-    bcc B3F_ed06
+    bcc @s48
     sbc #$30
-B3F_ed06:
+@s48:
     rol UNK_0
     cmp #$18
-    bcc B3F_ed0e
+    bcc @s24
     sbc #$18
-B3F_ed0e:
+@s24:
     rol UNK_0
-B3F_ed10:
     cmp #$0c
-    bcc B3F_ed16
+    bcc @s12
     sbc #$0c
-B3F_ed16:
+@s12:
     rol UNK_0
     cmp #$06
-    bcc B3F_ed1e
+    bcc @s6
     sbc #$06
-B3F_ed1e:
+@s6:
     rol UNK_0
     cmp #$03
-    bcc B3F_ed26
+    bcc @s3
     sbc #$03
-B3F_ed26:
+@s3:
     rol UNK_0
+@last_digit:
     cmp #$01
-    beq B3F_ed30
-    bcs B3F_ed34
-    bcc B3F_ed3c
-B3F_ed30:
+    bcc @last_y
+    bne @fix80
     cpy #$80
-    bcc B3F_ed3c
-B3F_ed34:
+    bcc @last_y
+@fix80:
     tax
     tya
     sbc #$80
     tay
     txa
     sbc #$01
-B3F_ed3c:
+@last_y:
     rol UNK_0
-    cmp #$01
-    bcs B3F_ed46
+    lsr a
+    bcs @fixc0
     cpy #$c0
-    bcc B3F_ed4b
-B3F_ed46:
+    bcc @done
+@fixc0:
     tya
     sbc #$c0
     tay
     sec
-B3F_ed4b:
+@done:
     rol UNK_0
     ldx UNK_0
     pla
-    clc
+    ; carry is zero after the final ROL (quotient is less than $80)
     adc $676d,x
     rts
+    .assert (*-B3F_ecf1) <= $64, error, "map divider too large"
+    .res $64-(*-B3F_ecf1),$ea
 B3F_ed55:
 .lobytes $68C8, $6988, $6a48, $6b08
 .lobytes $6bC8, $6c88, $6d48, $6e08
@@ -7833,45 +7868,75 @@
     rts
     tax
     rts
-    lda ram_BANKSELECT
-    pha
-    lda lower_prg
-    pha
-    ldx #$86
-    stx ram_BANKSELECT
-    lda #$1d
-    sta lower_prg
-    stx BANKSELECT
-    sta BANKDATA
-    lda upper_prg
-    pha
-    ldx #$87
-    stx ram_BANKSELECT
-    lda $0600
-    sta upper_prg
-    stx BANKSELECT
-    sta BANKDATA
-    jsr $8153
-    ldx #$87
-    stx ram_BANKSELECT
-    pla
-    sta upper_prg
-    stx BANKSELECT
-    sta BANKDATA
-    ldx #$86
-    stx ram_BANKSELECT
-    pla
-    sta lower_prg
-    stx BANKSELECT
-    sta BANKDATA
-    pla
-    sta ram_BANKSELECT
+; Experimental Spark collision memoization.
+; This replaces a verified unreachable duplicate tail following F8A0.
+; Hitbox hash includes position, size, flags, room, and map mode.
+; Cache lasts for no more than three skipped scans and only records
+; scans which returned carry clear. Other abilities use retail path.
+; SRAM 79B0-79B1 is an EXPERIMENTAL allocation in undocumented RAM.
+SparkCollisionCache:
+    lda hitbox1_x
+    eor hitbox1_x+1
+    asl a
+    eor hitbox1_y
+    eor hitbox1_y+1
+    asl a
+    eor hitbox1_width
+    eor hitbox1_height
+    eor hitbox1_flags_0501
+    eor current_room
+    eor current_room+1
+    eor $051e
+    cmp $79b0
+    bne @scan
+    lda $79b1
+    beq @full_scan
+    dec $79b1
+    clc
+    rts
+@scan:
+    sta $79b0
+@full_scan:
+    lda #$00
+    jsr B21_9426
+    bcs @hit
+    lda #$03
+    sta $79b1
+    clc
+    rts
+@hit:
+    lda #$00
+    sta $79b1
+    sec
     rts
+    .assert (*-SparkCollisionCache) <= $47, error, "Spark cache code cave overflow"
+    .res $47-(*-SparkCollisionCache),$ea
 
 B3F_f930:
-.byte $A9,$EE,$E2,$79,$AD,$F6,$E3,$F7
-.byte $6E,$D7,$AA,$AA,$EA,$E6,$AA,$AE
-.byte $EA,$98,$48,$A0,$09
+; Gameplay-specific NMI overrun latch. Only normal gameplay loop
+; calls this; menus and transitional WaitFrame calls retain vanilla timing.
+; Original nmi_done_flag remains a byte that NMI increments. The flag is
+; consumed immediately before each gameplay update so interrupts DURING
+; an update can count as its next frame boundary rather than being lost.
+WaitGameplay:
+    lda nmi_done_flag
+    bne @already_elapsed
+    jsr B3E_c067
+@already_elapsed:
+    lda #$00
+    sta nmi_done_flag
+    rts
+    ; This helper occupies exactly $F930-$F93B. The scanline IRQ
+    ; prologue at $F940-$F944 must remain unchanged.
+    ; Keep the original unknown data tail and all five live IRQ entry bytes.
+    .assert (*-WaitGameplay) = $0c, error, "game wait helper changed length"
+    .byte $EA,$E6,$AA,$AE        ; original fixed-bank bytes $F93C-$F93F
+B3F_f940:                      ; active IRQ entry from SetIrqHandler
+    nop
+    tya
+    pha
+    ldy #$09
+    .assert * = $F945, error, "the scanline IRQ entry moved"
 
 B3F_f945:
   	dey
--- a/src/prg/bank16.asm
+++ b/src/prg/bank16.asm
@@ -241,7 +241,7 @@
 B16_a17e:
     jsr $8049 ; KirbyPhysics
     jsr $a1ad ; KirbySpark_GetHitbox
-    jsr $9420 ; Kirby_DamageEnemyCollision
+    jsr SparkCollisionCache ; cached no-hit Spark terrain scan
     jsr $a19e ; KirbySpark_ShouldStop
     bcc B16_a191
     ldx #$42
```
<!-- END_CANONICAL_SOURCE_PATCH -->

---

## 9. Handoff summary for the next AI maintainer

**Treat the SHA-256 of the final ROM as the source-of-truth acceptance test.** Start with the specifically identified USA Rev 1 ROM and matching Nathan-R-Og disassembly. Extract §8 to a unified patch, apply to clean sources, run `configure.py` against the original ROM, compile with ca65/ld65 V2.19, and compare the resulting ROM hash.

The speedup has two different causes: genuine CPU-work reduction (especially the Spark collision memoization, plus map math and shared engine cleanup), and gameplay scheduling that avoids unnecessary waiting after already-arrived NMIs. The graphics and sound assets are unchanged. The full Spark visual effect script remains intact. The most serious documented correctness risk is the approximate Spark no-hit cache: treat it as a performance-versus-accuracy compromise, not a lossless replacement. The most serious maintenance risk is damaging the live scanline IRQ handler at `$F940`, or moving original source symbol addresses.

User testing impressions indicate that the optimized ROM runs smoothly in many demanding situations. An independent public comment reports operation on an EverDrive N8 / AV Famicom, with occasional dropped frames when the camera scrolls under heavy load; the same report notes that scrolling slowdown can also occur in the unmodified game. These are observational compatibility and performance notes, **not independently reproduced or quantified tests**. A controlled all-level performance trace, exhaustive collision-equivalence check, scrolling investigation, multi-device hardware verification, and ROM-hack compatibility matrix remain open. Preserve the canonical reproduced ROM unchanged while conducting follow-on research.
